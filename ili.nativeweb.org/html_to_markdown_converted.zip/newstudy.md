---
title: The Role of Christianity in Historic Oppression
---

## New Studies by Native American Scholar Document the Role of Christianity in Historic Oppression {#new-studies-by-native-american-scholar-document-the-role-of-christianity-in-historic-oppression align="center"}

### by Fred Whitehead {#by-fred-whitehead align="center"}

Last autumn I read in the Mid-October issue of the paper News from
Indian Country, a lead article by Valerie Taliman, \"Delegation wants
Vatican to revoke the Cetera Bull.\" This began with a quotation from
Steven Newcomb, a Shawnee/Lenape legal scholar: \"Indian people are
denied their rights in United States laws simply because they were not
Christians at the time of European arrival.\" Along with Birgil Kills
Straight, a Lakota from Kyle, S.D., and other participants from Central
and South American who spoke for indigenous rights, Newcomb spoke at a
panel during the Parliament of World Religions in Chicago last summer.

The article continued that this presentation \"was the first time that
many people heard about the undeniable relationship between the theft of
Native lands and the Catholic Church\'s ancient doctrines which
instructed Christians \'to capture, vanquish, and subdue\' enemies of
Christ\--including Native peoples\--and to take away all of their
property and possessions.\" The Indigenous Law Institute called on Pope
John Paul II to revoke the original Papal Bulls which authorized
Catholic sovereigns to seize lands of the heathen. So far as I know, the
present Pope has made no response.

Subsequently I exchanged a letter or two with Newcomb, who is working on
a book to be entitled Pagans in the Promised Land: Religion, Law, and
the American Indian. He also sent a short essay, A Matter of Religious
Freedom, which he published in 1992, giving an overview of his research,
as well as important references, notably a volume edited by Frances
Gardener Davenport, European Treaties bearing on the History of the
United States and its Dependencies to 1648 (Washington, D.C.: Carnegie
Institution, 1917). This should be available in college and university
libraries, as well as a few other larger public libraries.

The origins of this Papal doctrine may be traced to the conflicts
between Christians and Moslems in the 15th century. King Alfonso of
Portugal had caused his armies to do battle with the \"Saracens\" in
Africa, and extended his operations to Guinea. Pope Nicholas V, in the
Bull Romanus Pontifex (January 8, 1455) acknowledged the contributions
of Alfonso and his son Prince Henry to the \"cause\": \"\...many
Guineamen and other negroes, taken by force, and some by barter of
unprohibited articles, or by other lawful contract of purchase, have
been sent to the kingdoms. A large number of these have been converted
to the Catholic faith, and it is hoped, by the help of divine mercy,
that if such progress be continued with them, either those peoples will
be converted to the faith or at least the souls of many of them will be
gained for Christ.\" Such was the ideology of the birth of the infamous
Slave Trade.

Pope Nicholas then directed his attention to the rest of the world,
authorizing King Alfonso \"to invade, search out, capture, vanquish, and
subdue all Saracens and pagans whatsoever, and other enemies of Christ
wheresoever placed, and the kingdoms, dukedoms, principalities,
dominions, possessions, and all movable and immovable goods whatsoever
held and possessed by them and to reduce their persons to slavery.\"

Immediately upon hearing of Columbus\' \"discoveries,\" King Ferdinand
and Queen Isabella of Spain dispatched the news to Pope Alexander VI (a
notable reprobate), who issued a Bull, Inter Caetera (May 3, 1493),
greeting their recent victory over the Moslems in the siege of Granada,
but also noting the prospects for New World \"gold, spices, and very
many other precious things of divers kinds and qualities. Wherefore,
after earnest consideration of all matters, as becomes Catholic kings
and princes, and especially of the rise and spread of the Catholic
faith, as was the fashion of your ancestors, kings of renowned memory,
you have purposed with the favor of divine clemency to bring under your
sway the said countries and islands with their residents and
inhabitants, and to bring them to the Catholic faith.\" Alexander then
\"gave\" the new territories to the Spanish king and queen, with the
sole condition that no other Christian monarchs had previously held such
a dominion. For anyone who might happen to oppose this authorization,
Alexander stated: \"Should anyone presume to do so, be it known to him
that he will incur the wrath of Almighty God and of the blessed apostles
Peter and Paul.\"

The slaughter of Native Americans that then commenced was chronicled by
Father Bartholomé de las Casas, in his Destruction of the Indies, and
other works. Entire peoples were exterminated; literally millions were
slain in conquests of Peru, Mexico and so on. Many who were not
butchered by the sword died of appalling epidemics. All of this rapidly
grew into the \"Black Legend\" of Spanish and Portugese atrocities, and
was made much of in British propaganda, cheap editions of Las Casas,
including gruesome illustrations, were widely distributed.

From a legal standpoint, these Papal documents were important because
they fit into a theory of the fight of Discovery. A distinction was made
between Discovery and Occupancy, as if these lands had been inhabited by
wild animals instead of human beings. That is, a bear or a lion might be
said to occupy or live in a territory, but did not and could not have
title to it. That indigenous tribes occupied territory could not be
denied, but they had no rights, which could be authorized only by papal
authority. This legal background is discussed at considerable length in
Steven Newcomb\'s recent essay, \"The Evidence of Christian Nationalism
in Federal Indian Law: The Doctrine of Discovery, Johnson v. McIntosh,
and Plenary Power,\" in the New York University Review of Law & Social
Change (Vol. 20,1993, No. 2). \"This Article,\" Newcomb writes, \"brings
to the forefront an issue that has not been articulated previously:
should the United States continue to assert a plenary dominion over
Indians and an underlying vested property right in Indian lands based on
the historical fact that Indian peoples were not Christians at the time
of European arrival? Should Indian nations and people be denied under
United States Law their rights to \'complete sovereignty\' and an
exclusive right of territory in their lands on the basis of
Christianity?\"

As Newcomb summarizes it, \"Johnson v. McIntosh dealt with the validity
of a grant of land made by the Chiefs of the Illinois and Piankeshaw
Nations to private colonial individuals. The ruling, long acknowledged
to have been based on the discovery doctrine, served as the conduit to
place into United States law the concept of Christian discovery and
dominion. Chief Justice Marshall introduced these concepts in an opaque
fashion, carefully avoiding any explicit acknowledgment of the religious
basis of the ruling. As a result, most jurists, legal scholirs, and
federal Indian law practitioners have overlooked the religious
underpinnings of the Johnson decision.\" Newcomb proceeds to give a
brilliant review of the entire context of competing national interests
regarding \"new\" territories in the early modem period. Among Catholic
sovereigns, the Pope could mediate disputes, but what would happen with
the rise of the new Protestant powers, who did not acknowledge his
authority?

In his review of the legal background of imperial expansion, Marshall
noted: \"On the discovery of this immense continent, the great nations
of Europe were eager to appropriate it to themselves so much of it as
they could respectively acquire. Its vast extent offered an ample field
to the ambition and enterprise of all; and the character and religion of
its inhabitants afforded an apology for considering them as a people
over whom the superior genius of Europe might claim an ascendency.\"
Marshall then cited British King Henry VII\'s commissions to the Cabots
in 1496, \"to discover countries then unknown to Christian people, and
to take possession of them in the name of the King of England.\" The
formula authorizing dominion over the heathen was repeated in subsequent
British charters, cited by Marshall, who concluded that the authority of
the federal government had to take precedence over Indian territorial
rights.

Newcomb then cites numerous additional legal authorities who supported
Marshall\'s views. For instance, Joseph Story was a friend of
Marshall\'s and also a Supreme Court Justice. In his Commentaries on the
Constitution of the United States (1833), Story wrote approvingly of
Alexander VI\'s 1493 Bull as a legal precedent, and concluded that
\"discovery gave title to the government\...being once established, it
followed almost as a matter of course, that every government within the
limits of its discoveries excluded all other persons from any right to
acquire the soil by any grant whatsoever from the natives.\" Other
distinguished jurists concurred, up to and including the present day,
and these are duly cited by Newcomb.

An important point that he makes is that in recent scholarship, the
religious nature of the conflict has been obscured. Thus, scholars have
tended to tactfully refer to \"European\" authority, omitting the
\"Christian\" content of the original charters, etc. That is, Newcomb
provides a welcome and quite fundamental corrective to what actually
happened in history. Furthermore, he contends, with the force of truth
in his words, that the Marshall decision \"carried powerful implications
for Indian peoples that transcended the question of their title. In all
subsequent cases involving Indian issues, the Court continued to assume
as a fundamental principle that Indian rights to complete sovereignty,
as independent nations had, in a sense, evaporated after
\'discovery.\'\" Newcomb observes that many court decisions after
Marshall\'s time \"would avoid mentioning Christian dominion,\" but that
\"it was to become the true basis of later United States assertions of
plenary power over the American Indian. Under this fiction Indian
nations are said to be subject to the legislative authority of the
United States.\"

I have cited Newcomb\'s text at length here because it is necessary to
show his language and his argument in detail. Among his other points is
the observation that citing Christian dominion or a religious rationale
for territorial rights clearly contradicts the First Amendment of the
Constitution, separating Church and State. He refers to various legal
scholars who argue that the doctrine of Discovery is so deeply rooted in
precedent that \"it is too late to question the foundations of federal
Indian law.\" In response, Newcomb contends that it is never too late to
correct such a grievous and fateful error. \"It is to contend,\' he
says, \"that Indian nations ought to learn to accept a judicial
pretention based on religious and cultural prejudice that asserts that
their rights to complete sovereignty and to territorial integrity may be
impaired, diminished, denied, or displaced simply because they were not
Christian people at the time of European arrival to the Americas. It is
to accept the preposterous idea that federal Indian law will forever
rest on the foundation of a subjugating Christian ideology.\"

Newcomb\'s writing style in this remarkable essay is far and away
superior to most legal literature. Perhaps the author\'s background in
rhetorical theory and communication has given him a particular skill in
this respect. He clearly elucidates a great deal of difficult material,
demonstrating how fundamental these arguments have been for 500 years.
His level of sophistication is indeed impressive; I found this to be so
with many Native American activists and thinkers I have met. For
instance, at one point, Newcomb cites Rousas J. Rushdoony\'s Institutes
of Biblical Law \-- one of the key texts of the Christian
Reconstructionist movement, which would have the entire government of
the United States placed under Christian laws (of their interpretation,
of course). That Newcomb has a number of allies in the Indian community
is suggested by his appendix, a 1992 communiqué on discovery, heathens,
slavery and religious freedoms, issued by the Traditional Council of
Indian Elders and Youth at the Sapa Dawn Center, Yelm, Washington.

------------------------------------------------------------------------

> \[Note: the issue of the law review in which Newcomb\'s article
> appears is entirely devoted to \"The Native American Struggle:
> Conquering the Rule of Law,\" with many other essays of similar
> interest. The price is quite reasonable, at \$6.00 from The New York
> University Review of Law & Social Change, 110 W. 3rd Street, New York,
> NY 10012.

------------------------------------------------------------------------

> **DOCUMENT SOURCE:** Whitehead, Fred. \"New Studies by Native American
> Scholar Document the Role of Christianity in Historic Oppression.\"
> Freethought History.\" #9/1994. ISSN# 1071-7269.\
>
> Freethought History\
> Box 5224\
> Kansas City, KS 66119

------------------------------------------------------------------------

![](images/oil9-la.jpg){align="left" hspace="5"}[**Return to Indigenous
Law Institute home page**](index.html)

------------------------------------------------------------------------

Original web page design by [Jeanne Ley](mailto:angel4u@teleport.com).
