---
generator: BBEdit 7.1.1
title: Pu\'uhonua Peace Pact
---

# The Pu\'uhonua Peace Pact {#the-puuhonua-peace-pact align="center"}

### Submitted to The Hague Appeal for Peace May 11-15, 1999 The Hague, Netherlands {#submitted-to-the-hague-appeal-for-peace-may-11-15-1999-the-hague-netherlands align="center"}

### Prepared by Nalani Minton\* and Steven Newcomb\*\* on behalf of [The Indigenous Law Institute](index.html){target="_BLANK"}, The Kanaka Maoli Tribunal Komike, and [The Fourth World Center for the Study of Indigenous Law and Politics](http://carbon.cudenver.edu/public/fwc/fwcabout.html){target="_BLANK"} {#prepared-by-nalani-minton-and-steven-newcomb-on-behalf-of-the-indigenous-law-institute-the-kanaka-maoli-tribunal-komike-and-the-fourth-world-center-for-the-study-of-indigenous-law-and-politics align="center"}

------------------------------------------------------------------------

\*Nalani Minton is a Kanaka Maoli representative of the Tribunal Komike
on issues of self-determination and the advancement of cultural law as
an instrument of global peace and recovery from colonialism. She is also
a board member of the Indigenous Law Institute, co-publisher of Ku\'e:
The Anti-Annexation Petitions of 1897-98, as well as producer of
cultural documentaries on cultural systems of self-governance that
pre-date colonialism.
([nalanima@aol.com](mailto:nalanima@aol.com){target="_BLANK"})

\*\*Steven Newcomb (Shawnee/Delaware) is Director of the Indigenous Law
Institute, and author of \"The Evidence of Christian Nationalism in
Federal Indian Law,\" published by the New York University School of Law
in the Review of Law & Social Change. Since 1981, Newcomb has been
researching the origins of U.S. federal Indian law, international law,
and issues of Christian European and state colonialism. 1430 Willamette
#608 Eugene, Oregon 97401 (541) 343-3091
([stv4newcomb@aol.com](mailto:stv4newcomb@aol.com){target="_BLANK"}).

------------------------------------------------------------------------

## The Pu\'uhonua\* Peace Pact {#the-puuhonua-peace-pact-1 align="center"}

### A Declaration of Vision from the Cultural and Spiritual Perspectives of Indigenous Peoples {#a-declaration-of-vision-from-the-cultural-and-spiritual-perspectives-of-indigenous-peoples align="center"}

\"Government without the consent of the governed is the very definition
of slavery.\"

\"Real Power is our relationship with the earth. We are the earth\...
\[human.beings\]\...are just different shapes and forms of the life of
the earth,\...no more or less than the trees \...\[and\]\...
stones\...human physical, being spirit. Authority is not power.
Authority is something man creates. All authority is usually based upon
aggression or implied aggression. Whoever has the most money has the
ability to \[buy\] authority, but that is not power. The industrial
technological authoritarian political system that we live under, has
developed a way to mine the human spirit just as it mines all natural
resources. We are being mined in the same way that \[oil\] is mined, out
of the earth. The pollution of the air, of the water, \...of the
environment \...comes from this plundering and mining of the planet in
an irresponsible manner. Every fear, every doubt, every insecurity,
every way that we ever beat ourselves up inside of our own
heads,\-\--that is the pollution left over from the mining of our spirit
\...by the confusions that are in our minds. There is no existing cure
to the problem, the disease, than the one we create by using our
intelligence as intelligently and as clearly as we possibly can. Either
we know or we don\'t know. Our ancestors are our power connection to
knowledge. Real Power is what we come from. It is part of the natural
order of the universe. Real Power has no limitations. Real Power cannot
be removed from us, it is a natural part of us. Any relationship we will
ever have to Real Power is our relationship to the earth. \[We must
re-establish\]\...our connection to that basic reality, we must take
care of the earth.\"\
**(Excerpted from the spoken words of John Trudell at the memorial for
Earth First activist Judi Bari, April 26, 1997.)**

E mau ke ea o ka \'aina i ka pono, the life and spirit of the land is
protected by the spiritual relationships of the People in maintaining
Life sustaining cultural systems and cosmic intelligence.

------------------------------------------------------------------------

\* A pu\'uhonua is a place of being, refuge, peace and safety. The new
paradigm of world peace must be a living realization of the Earth as
such a place.

------------------------------------------------------------------------

### Introduction

We, as representatives of the Indigenous Law Institute, the Kanaka Maoli
Tribunal Komike, and the Fourth World Center for the Study of Indigenous
Law and Politics, welcome the opportunity presented by the Hague Appeal
for Peace to help create a new paradigm of peace that respects the
existence and the collective, inalienable rights of all peoples of the
world. For thousands of years, and to the present day, the Indigenous
nations and peoples of the world have served as protectors of waters,
lands, oceans, seeds, foods, medicines, life forms, and life systems of
the natural world. However, because the present economic industrial
world system, rooted as it is in the pathology of Western colonialism,
militates against Indigenous cultural systems of right relationship with
the natural world, an Appeal for Peace, from our perspective, must also
address the issue of colonialism as a culture of war. A peaceful world
requires an end of all forms and manifestations of colonialism so that
the cultures of peace that predate colonialism may thrive and flourish
and a new global culture of peace may be created.

### Original Independence, Indigenous Cultures of Peace, and Self-Determination

Originally, Indigenous nations and peoples were entirely free and
independent, inherently and naturally self-determining throughout time,
living self-sustaining ways of life in our homelands, in keeping with
the patterns of right relationship and community with one another, and
with all life. For countless generations we have spoken our own
languages, honored our child-rearing practices and family systems, and
practiced cultural decision-making based on an acknowledgement of the
needs of future generations, and the profound ecological interdependency
of nature. We have inherited from our ancestors knowledge and wisdom
accumulated over thousands of years of living as distinct peoples of
cultural integrity. Accordingly, we as Indigenous peoples have many
gifts and vital contributions to offer other peoples of the world toward
the global effort to live life in a balance that profoundly cares for
and sustains all life in a Sacred Circle of ecological and cultural
renewal. The protection of both cultural diversity and bio-diversity are
essential to the survival of the earth, all peoples, and all life.

According to Kanaka Maoli traditions of Ka Pae \'Aina Hawai\'i, human
beings are not the law-makers. The spiritual life givers of land and
water that sustain all life are the law givers, and human beings have
the responsibility to harmonize their life through a sacred response to
the laws of the natural world, thus honoring the sustaining of life
energy and life renewal systems throughout time. Laws of renewal that
follow from these cultural practices include: asking permission before
taking anything needed from the natural world, taking only what is
immediately necessary, sharing with others what is taken, not wasting or
contaminating, respecting the needs of all living generations and
respecting the needs of all generations to come.

Ka \'uhane lokahi describes the well being of spirit in harmony within
oneself and with all levels of community, including the cosmos. When
people live in this state of well being they interact in right
relationship with themselves, their families, their communities, and the
natural world. This is being pono. Each person carries personal
responsibility to create and live pono relationships on all levels. Pono
relationships are nourished by the loving compassion of sharing and
caring for all life as family with aloha. Aloha is the energy of
synchronous relationship between mind, heart, body and soul by which the
allignment of each pono person connects them in right relationship with
the whole universe. When aloha becomes the energy of the people, life is
sustained within and without. We say that by caring and sharing, called
malama, the people carry light. A natural state of enlightenment based
on a profound practice of caring and sharing is called malamalama. This
way of life honors the reality of i ke kahi i ke kahi, one shared
consciousness which connects and integrates all life as one living
intelligence. In this way, human beings increase the mana, the life
force energy that they were born with, through the good deeds of their
lives which honor right relationship, and are spiritually guided in
conscious communication with the whole continuum of life. This natural
state of being, meaning and life purpose restores lokahi, harmonious
relationship, health, wellness and life renewal.

Natural laws of renewal are practiced within the ahupua\'a systems of Ka
Pae \'Aina Hawai\'i. Ahupua\'a systems are natural land systems,
including water systems, land formations, and growing zones of various
elevations, from the cloud zones of the high mountains, through the
forested and open plains areas, downward to the coastal areas and reefs,
and into the near shore and deep ocean fishing waters. Within this way
of life, the family systems within each ahupua\'a evolved intelligent
responses to the unique ecosystems and life systems of the \'aina, that
which feeds, nourishes and sustains life.( in English referred to as
\"land\"). These natural communities also provide what is needed to
sustain life for everyone and are the foundation of the evolution of
creating abundance as an integral responsibility of human beings in a
culture based on sharing. The spiritual and genealogical relationship of
the people to the \'aina is the source of the culture and the cultural
integrity, values, practices and skills that sustain the culture. The
cultural identity of the people comes from the \'aina and is profoundly
expressed as ea, the life, breath, spirit. Ea has been inadequately
equated with the Western term \"sovereignty\".

Ku\'o ko\'a expresses the responsibilities of the people to care for,
protect, and enhance the natural world. Ku\'o ko\'a is the Kanaka Maoli
meaning of inherent self-determination. For families living within an
ahupua\'a, community decision-making is a way of life. Inclusion of
representatives from all areas of cultural life in decision making
councils of each ahupua\'a creates a foundation for consensus and common
understanding that sustains peace and harmony in community life.
Ahupua\'a councils were active for thousands of years prior to the
imposition of hierarchical governing by the ali\'i (ruling chiefs) and
subsequent colonizers. Some ahupua\'a communities survived colonialism,
and others are now being revived. Ahupua\'a councils are some of the
earliest forms of cultural self-government in Ka Pae \'Aina Hawai\'i and
are the means by which Kanaka Maoli live spiritually within a culture of
peace, abundance and life renewal.

Another example of an Indigenous culture of peace is found in the Woope
Sakowin (seven laws) of the Oceti Sakowin (Great Sioux Nation). Living
with these seven laws results in peace and friendship, known as
Wolakota. The laws are: honor and respect; compassion and pity; caring
and sharing; humility; to carry the welfare of the people in one\'s
heart; bravery and courage; seeking wisdom and seeking understanding.
The Oceti Sakowin prayer of mitakuye oyasin (\"all my relations\") is an
acknowledgement that all life, including the spirit world, is family. It
is an acknowledgment of life\'s sacred web of interconnectedness and
interrelationships, within which human beings are neither higher nor
lower than any other life forms. According to the Oceti Sakowin, human
beings have a sacred responsibility to honor the ongoing processes of
life by living with the seven laws in a spiritual relationship with all
living things. Black Elk, a holy man of the Oceti Sakowin, described a
three-fold peace that comes from living in a sacred manner. The first
peace is that which is found within one\'s heart upon realization of
oneness with the universe and all its powers. The second is that which
is shared between two or more people. And the third is that which is
shared between two or more nations. But none of these is possible
without first finding the peace within one\'s heart that comes with the
realization of oneness with the universe and all its powers.

### The Basic Foundations of Colonialism, International Law, and U.S. Indian Law

More than five centuries ago, in the earliest known example of
globalization, the European nations of Western Christendom began to
conquer other parts of the world. They did so based on an assumed
authority and domination over the entire earth without any regard for
the destruction of life\'s delicate balance, or for the suffering of the
hundreds of nations they subjected to genocide. An Appeal for Peace is
now made necessary at the dawn of the 21st century because of the
present day consequences of a global culture of war and colonialism
dating back to the fifteenth century. The culture of war has set into
motion and institutionalized destructive policies through the laws and
processes of domination, militarism, subjugation, and exploitation.
Therefore, an Appeal for Peace must include the global eradication of
colonialism in order to recover from the devastating traumas that
colonialism inflicts on the earth\'s ecological systems, peoples, and
nations.

Colonialism is a culture of war, violence, domination, exploitation and
genocide. It is the forceful imposition of imperial or state laws,
policies and controls by colonial settlers, in the homelands and
territories of free and independent peoples whose existence pre-dates
the arrival of the colonial settlers. Colonialism is waged in order to
secure and protect the settlers\' self-interests, without regard for the
survival of the original peoples and nations. Colonialism involves the
effort to destroy and remove the pre-existing peoples and their culture
from the land for the sole benefit of the dominating settler population.
Colonialism has devastating social, cultural, and environmental
consequences because it is based upon the insatiable needs of a market
economy and the industrialization of peoples and environments, in order
to consolidate wealth and resources by commodifying all life forms as
property. Colonialism is the forceful domination of peoples, nature and
life \"which may exist within a continuous land area, and even within a
politically and geographically homogeneous state, such as Australia and
the United States, and does not necessarily involve long distances.\"
(Dr. Laura M. Thompson, Steps Toward Colonial Freedom, 1943, p. 4)
Although colonialism sometimes involves long distances, it also occurs
when the colonizers currently do not come from some distant region
separated by a body of blue water from the colonized.

Colonialism is a culture of genocide because it results in the utter
destruction of entire peoples. Genocide is the most extreme form of war
waged by one people against another. It is based on racism and bigotry
by which entire peoples and their cultural ways of life are dehumanized
and destroyed. When a colonial settler people establish a system of
domination over another people, they generally create genocidal laws and
policies designed to physically eliminate Indigenous cultures and
peoples, to prevent births within their populations, and to indoctrinate
and condition the children to participate and assimilate into the
dominant colonial establishment, or else to self-destruct. While
massacres are the most obvious and horrendous evidence of genocide,
genocide also includes state policies that organize against the cultural
and physical survival of Indigenous peoples and their ability to live
and pass on their culture and way of life in their own territories and
homelands to new generations. Also genocidal is the enforcement of
colonialism, racism, violence and intimidation through state policies of
coercive assimilation of Indigenous peoples into the general population
and urban sectors of the dominating civil society.

From an Indigenous peoples\' perspective, an appeal for world peace must
include an examination of the origins and present day manifestations of
colonial and genocidal behavior that have created sweeping contemporary
policies and practices that contradict the long-term survival of life on
earth. Further, all the peoples of the earth need to create processes of
recovery and healing while preventing new forms of colonialism, and
their intensification, based on the racist assumed superiority of some
nations or peoples over all others. Global peace will remain
unattainable so long as the coercive imposition of laws of discovery,
conquest, domination, assimilation, and dehumanization remain encoded in
international law and in the domestic legal systems of specific states,
such as are found in United States federal Indian law.

The colonialism and genocide that Indigenous peoples have been subjected
to for over five centuries are rooted in the era of Western Christendom.
Behind Western Christendom\'s early conquests was a long succession of
popes at the Vatican in Rome. These popes, in eighteen documents called
\"papal bulls\" authorized rights of discovery, conquest, extermination,
genocide, and subjugation to the Christian European colonizers of that
time. The king of Portugal, for example, was instructed to \"capture,
vanquish, and subdue\" infidel peoples, \"to put them into perpetual
slavery,\" and to take away \"all their possessions and property.\" In
1493, shortly after the first voyage of Cristobal Colon to the Americas,
Pope Alexander VI issued the Inter Cetera bull of May 4th, in which he
called for \"barbarous nations\" to be \"subjugated\" or overthrown so
as to \"propagate\" the \"Christian Empire.\"

The Inter Cetera bull, and many preceding papal bulls, became the
cornerstone of a world system of colonization involving many empires of
Christendom, such as Portugal, Spain, England, France, Holland, and
Russia. Much of the present system of international law relating to
Indigenous nations and peoples was developed on the basis of these papal
documents and on the colonial customs shared by the empires of
Christendom. Henry Wheaton, in his Elements of International Law,
expressed the status of Indigenous peoples in relation to the \"States
of Christendom\" when he wrote, \"The heathen nations of the other
quarters of the globe were the lawful spoil and prey of their civilized
conquerors.\" The empires or states of Christendom became known as the
Family of Nations in Europe, who were later joined by the United States
and other nations such as Japan, Turkey, and China. The law of nations
from which international law was gradually developed, emerged from this
society of colonizing powers, eventually led to the failed League of
Nations, and, ultimately, to the United Nations system of states. The
present system of world powers such the United States (now considered
the world\'s sole superpower) Canada, Australia, and New Zealand, in
tandem with powerful transnational corporations, derive their framework
of consolidating the world\'s resources and subjugating the world\'s
peoples from Christendom\'s prototype of empire and colonization.

Current international trends signal a new intensification of
colonialism. Evidence of these trends includes the World Trade
Organization (WTO), the International Monetary Fund (IMF), the
Multilateral Agreement on Investments (MAI), the Global Agreement on
Trades and Tariffs (GATT), the North American Free Trade Act (NAFTA),
the Asian Pacific Economic Council (APEC), the Human Genome Diversity
Project, and the Biodiversity Convention. Further evidence is the move
towards the corporate patenting of all life forms as property within the
global trade agreements of transnational corporations and nation-states.
Through such international agreements, by conglomerates forcing economic
globalization on the world, a framework has been created that bypasses
the consent of all peoples. Through the resulting international system
of plunder based on selective monopolization through massive corporate
mergers, transnational corporations have exempted themselves from
environmental and labor laws, and protective collective agreements like
the Law of the Sea to create a lawless world regime that inflicts
ultimate devastation on the earth. In the first trade agreements between
the US, the UK and China, based on cultural and intellectual property
rights, the whole subsurface of the Pacific Ocean floor as \"open
mining\", neither defined as land or water and therefore not subject to
the protective limits of governments, nations, and the Law of the Sea.

### Proposed Remedies and Recommendations

A variety of international documents and legal instruments already
recognize that \"all peoples\" of the world have the right of
self-determination, and therefore have the right to live free of
colonialism and colonial rule. The United Nations Charter, the
International Covenant on Civil and Political Rights (ICCPR), the
International Covenant on Economic, Social and Cultural Rights (ICESCR),
the United Nations Declaration on the Granting of Independence to
Colonial Countries and Peoples (UNGAR 1514) and the Draft Declaration on
the Rights of Indigenous Peoples, recognize that all peoples have the
right of self-determination. Colonialism is an international crime
because it is an impediment to world peace. Peoples forced against their
will, and without their consent, to live under conditions of
colonization, colonialism, and alien rule, will always strive to free
themselves from oppression.

The human rights violations of \"all peoples\" are some of the most
notorious root causes of war. Human rights principles inherently protect
the rights of all peoples by restoring the rights of those whose rights
have been violated by the current system of nation-states. The
nation-state system as it evolved from the Law of Nations was created to
enforce colonialism, war, violence and genocide. The UN system was
created to eradicate colonialism. Therefore, the nation-state system of
colonialism must be replaced in order to eradicate colonialism.
Self-determination for all peoples of the world must become the new
decolonization process. It is a mandate of the United Nations Charter
that colonialism be eradicated by the year 2000. Therefore, one task of
the world community of peacemakers will be to recognize all new forms of
colonialism based in economic globalization. In the interest of
expanding human rights and humanitarian law to promote global peace, the
world community must make a firm commitment to eliminate colonialism in
all its current and projected forms.

Toward this end, we must openly acknowledge that the United Nations and
the international law system operates on the basis of a major
contradiction. At the same time that the international human rights
framework upholds the right of all peoples to self-determination, the
Member States of the world community are attempting to deny that
Indigenous nations and peoples have an already existing right of
self-determination by continuing to hold them under neo-colonial rule.
By doing so, Member States themselves are directly contradicting the
United Nations\' mandate to eradicate colonialism. The high ideals
stated in the language of humanitarian principles are eroded by policies
of state self-interest based on the assumption that the right of
self-determination is exclusively a right of Member States who determine
through a circuitous process of decolonization by which they control
which peoples, and to what extent they will allow limited
decolonization. The UN Decolonization Committee may succumb to a
contrived \"end of colonialism\" that will discontinue the current UN
process of decolonization rather than fulfill its mandate to eradicate
colonialism by the year 2000.

### Remedies and Recommendations

That the international community, through the Hague Appeal for Peace
Agenda for Peace and Justice for the 21st Century, support the expansion
and application of human rights and humanitarian law, and, explicitly
recognize the inalienable rights of Indigenous peoples to inherent
sovereignty and self-determination.

That it be the official policy of the United States, other UN member
states, and the international community that Indigenous nations and
peoples be recognized as having the same right of self-determination as
\"all peoples\" in international law. Such recognition is in keeping
with the UN Draft Declaration on the Rights of Indigenous Peoples, the
ICCPR, ICESCR, the UN Charter, the Universal Declaration on Human
Rights, UNGAR 1514, the Genocide Convention, and other international
documents that recognize and affirm fundamental protections for the
rights of all peoples.

That in order to eradicate colonialism, as is mandated in the UN
Charter, for the establishment of global peace, the universal
application of self-determination for all peoples be affirmed, the
legitimacy of states challenged and the world system of colonialism
abolished.

That, as expressed in the UNESCO Barcelona Statement of November 1998,
the right of self-determination for all peoples be peacefully
implemented and applied equally and universally as an instrument of
global peace and conflict resolution in order to foster cultures of
self-determination and peace.

That the Hague Appeal for Peace support the UNESCO initiative to promote
the use of the existing human rights agencies of the UN and other
international organizations to create a process at the UN Commission on
Human Rights for implementing the right of self-determination of all
peoples, and that the Decade for the Rights of Indigenous Peoples be
extended within the upcoming Decade for Non-violence in order to provide
a transition period of time to promote global understanding and the
creation of just remedies, including a relevant, cultural decolonization
process for Indigenous nations and peoples, and all peoples not yet free
of colonial domination, based on their own cultural processes and free
and informed consent.

That financial and organizational support be forthcoming from the
international community for regional forums for those peoples struggling
for self-determination; that such forums be developed as venues where
Indigenous peoples may prepare to raise issues and specific cases before
the UN Commission on Human Rights, and before other relevant
international bodies in an effort to advance their own cultural
remedies, and to correct the violations of international human rights
law.

That these regional forums represent the cultural foundations for
restoring self-determination through cultural education, through the
creation of cultural economies, as well as through the revitalization of
Indigenous languages, customs and laws, in order to promote a more
informed and profound interaction with the processes for implementing
rights of self-determination to all peoples within the UN Human Rights
Commission and the UNESCO initiative.

That the UN Draft Declaration on the Rights of Indigenous Peoples be
removed from the UN Intersessional Working Group of Member States, and
that it then be submitted regionally to Indigenous peoples as a central
documents for review, amendment, agreement, and acceptance regarding
their rights of self-determination, and that the UN Draft Declaration
for the Rights of Indigenous Peoples be protected by the UN Human Rights
Commission as the expression of the minimum standard for the rights of
Indigenous nations and peoples.

That the reporting by Indigenous representatives at the UN Human Rights
Commission during the past twenty years, be collected, catalogued and
preserved as a permanent record of the existing and ongoing human rights
violations against the physical and cultural survival of Indigenous
nations and peoples, as evidence of the violations against Indigenous
peoples\' rights to self-determination and inherent sovereignty, and as
evidence of the continuing genocide of colonialism against Indigenous
peoples.

That International Peoples\' Tribunals be organized to create a process
of accountability to support the recovery of Indigenous peoples from
historical and devastating traumas due to the devastating effects of
intergenerational colonialism, and the proliferation of cultures of
self-determination and cultures of peace to offset and balance the
imbalances resulting from patterns of global domination. That
documentation of these tribunals be forwarded to the UN Human Rights
Commission to support the implementation of self-determination for all
peoples.

We recommend that the 1948 Convention on the Prevention and Punishment
of Genocide be applied to the situations and conditions of Indigenous
nations and peoples in order to promote global peace. To this end, peace
education must include the common understanding that the crime of
genocide means any of the following acts committed with the intent to
destroy, in whole or in part a national, ethnical, racial, or religious
group by:

a\) Killing members of a group;

b\) Causing serious bodily or mental harm to members of the group

c\) Deliberately inflicting on the group conditions of life that bring
about its physical destruction in whole or in part

d\) Imposing measures intended to prevent births within the group

e\) Forcibly transferring children of the group to another group

As stated in Resolution of Indigenous Participants to the 14th Session
of the UN Working Group on Indigenous Peoples on a process of reporting
and reviewing continuing genocidal actions, violations of the Genocide
Conventions and policies against the rights and survival of all peoples
and nations must develop mechanisms for accountability and for bringing
an end to genocide in all its forms and manifestations.

We recommend that an International Court of Justice in cooperation with
the formation of the International Criminal Court be convened to address
acts and policies of genocide against Indigenous nations and peoples,
and to recommend effective remedies. Also, that provisions be created
for the inclusion of evidence from Indigenous Peoples\' International
Tribunals in the International Criminal Court proceedings.

That the specific recommendations included within the Hague Agenda for
Peace and Justice to counter the adverse effects of globalization, and
to eradicate colonialism and neo-colonialism be implemented by the world
community.

We call upon the international community and the Human Rights Commission
to acknowledge that the policies and practices of economic globalization
represents an intensification of colonialism and continuing genocide
that constitute a war of aggression against all life. We, call for the
Human Genome Diversity Project to be discontinued, and for the
Biodiversity Convention to be revised to remove all threats to
Indigenous peoples and communities. We call on religious communities,
human rights, social justice, and environmental organizations, funding
agencies, individuals and institutions to refuse to participate, fund,
or provide other assistance to the Human Genome Diversity Project and
any related programs.

We condemn the exploitive use of instruments of intellectual and
cultural property rights, patent laws, and all instruments of economic
and trade manipulation such as NAFTA, GATT, APEC, MAI, as crimes against
humanity under the guise of legitimacy, validity and law. We therefore
appeal to the world community, which suffers comprehensive violations
and global denial of consent, to disavow and create universal legal
standards against the institutionalization of exploitation, poverty,
dependency and war through economic globalization. The World Trade
Organization, transnational corporations, the IMF, the World Bank, and
the organized assistance of governments and military forces which
continue to exploit peoples and natural resources for profit by imposing
Western deception and theft on the natural world must be held
accountable for their crimes and effectively ended.

That the world system of states be replaced in the 21st century by a new
paradigm of peace premised on the existence and rights of \"all
peoples.\" New cultural systems are needed to replace the culture of
colonialism, violence, war and genocide. It is necessary to reorganize
globally according to a world community of \"all peoples,\" while
reorganizing regionally according to local communities of humanitarian
and cultural integrity based on viable ecological sustainability. A new,
world system of peoples is needed to replace the old, world system of
states. To create a new level of peaceful responsibility to the human
family, to the earth, and to all living things, this new world system of
peoples must operate on the basis of the continual renewal of all life.

That terms such as \"Indigenous peoples\" be used temporarily to correct
inequalities and injustices, broaden human rights, and address concerns
and violations of peoples previously dehumanized and excluded from
international remedies. That the term \"Indigenous peoples\" not be used
to rename or justify racism on a global level, and be understood within
the context of the term \"all peoples,\" as it is applied to secure the
rights of all peoples of the world. That the term \"all peoples\"
include the recognition of the diversity of names, languages, values,
cultures, histories, economies, social and political systems which bring
dignity to the reality of \"all peoples.\"

That the world community call upon Pope John Paul II, and the Vatican,
to formally revoke the Inter Cetera bull of May 4,1493, which has stood
for over five centuries as the cornerstone of the old world system of
colonialism, colonization, and domination which must now be replaced so
that there truly can be peace and justice in the 21st Century in order
that a new paradigm of world peace based on the global community of
\"all peoples\" may be realized. That Christian missionary
evangelization, proselytization, indoctrination, and moves toward
assimilation through deculturalization be ended.

That the world community support the convening of Peoples\'
International Tribunals to challenge and document the continuing
existence and violations of colonialism and to create just remedies and
recommendations to correct the injustices inflicted against the people.
Such Peoples\' International Tribunals affirm that law must have a moral
component and that it is immoral for those who presume colonial
authority to suppress the people or the truth. A recognized value of
such tribunals is that oppressed peoples have the right to disassociate
themselves from the crimes and definitions that have been developed by
their oppressors to serve only the interests of the oppressors. Such
tribunals are not only designed to punish criminals, but also to deter
future crimes, such as the subordination of human rights beneath the
geopolitical economic interests of the most militant nation states. Such
tribunals bring before the court of world opinion historical, moral,
political and \"legal\" pressure against the continued wrongs of
colonialism. Indigenous peoples and nations have a significant
contribution to make through tribunals to the reform of international
laws, instruments and standards by expanding humanitarian law through
cultural laws, principles, values, conflict resolution practices and
traditions that predate colonialism and western constructs. Such
tribunals educate the world about the wrongs of colonialism and bring
full dignity to processes of becoming independent of the genocidal
practices of colonialism and evolving interdependent relationships and
responsibilities between nations and peoples and the natural world.

------------------------------------------------------------------------

[![Hosted by
NativeWeb](../www.nativeweb.org/hosted/hostedbynw.gif){border="0"
align="right" width="109"
height="110"}](../www.nativeweb.org/index.html)
