---
generator: BBEdit 5.1.1
title: "A Mau A Mau: to continue forever"
---

::: {align="center"}
# A MAU A MAU: to continue forever

![John Ka\'imikaua](images/amau_tn.jpeg){width="180" height="125"}

## Cultural and Spiritual Traditions of Moloka\'i Life Giving Knowledge of Peace  with Hãlau Hula O Kukunaokalã

### A video presentation composed and produced by [Nãlani Minton](mailto:Nalanima@aol.com)

![Nalani Minton](images/nalani.jpeg){width="90" height="106"}

### Videography and Sound by Nã Maka o ka \'Aina

### Editing by Robert Oshita and Nãlani Minton at Alphamedia

##### Running Time: 59:49

##### ©2000 - Nãlani Minton and John Ka\'imikaua

##### [Full-size JPEG image of video cassette cover \[170k\]](images/amau.jpeg) Cover Design by Nai\'a - <mo_ike@lava.net>
:::

------------------------------------------------------------------------

For further information contact: Nãlani Minton - <Nalanima@aol.com>

AND

Hãlau Hula O Kukunaokalã\
Ka\'ana Kapu\
89-314 Lepeka Avenue\
Nanakuli, Hawai\'i 96792
